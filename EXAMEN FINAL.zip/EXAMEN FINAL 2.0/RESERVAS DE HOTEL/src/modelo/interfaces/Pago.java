package modelo.interfaces;

public interface Pago {
    double calcularTotal();
}
