package modelo;

public enum TipoHabitacion {
    INDIVIDUAL,
    DOBLE,
    SUITE
}
